﻿using API_Jewelley_Management.BAL;
using Microsoft.AspNetCore.Mvc;

namespace API_Jewelley_Management.Areas.Website.Controllers
{
    [Area("Customer")]
    [ApiController]
    [Route("api/[controller]")]

    public class DashboardController : Controller
    { 
        

        //public async Task<IActionResult> Index()
        //{

        //}
    }
}
