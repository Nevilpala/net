﻿namespace API_Jewelley_Management.Areas.Website.Models
{
    public class JewelleryCategory
    {
        public Dictionary<string,dynamic> Category { get; set; } 

    }
}
