﻿namespace API_Jewelley_Management.BAL
{
    public class Common_BAL
    {
        public bool CommonUpdate(bool flag)
        {
            return flag;
        }

    }
}
